import boto3
import json

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
table_name = 'Users'
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    # Extract email from query string parameters
    email = event.get('queryStringParameters', {}).get('email')
    
    if not email:
        return {
            'statusCode': 400,
            'body': json.dumps({"error": "Email is required"})
        }
    
    # Query DynamoDB
    try:
        response = table.get_item(Key={'Email': email})
        
        # Check if the user exists
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({"error": "User not found"})
            }
        
        student = response['Item']
        missing_fields = []
        
        # Check for missing fields
        if not student.get('About'):
            missing_fields.append('About')
        if not student.get('Phone'):
            missing_fields.append('Phone')
        if not student.get('linkedin profile'):
            missing_fields.append('LinkedIn Profile')
        
        # Return missing fields or success
        if missing_fields:
            return {
                'statusCode': 200,
                'body': json.dumps({
                    "message": "Profile incomplete",
                    "missing_fields": missing_fields
                })
            }
        
        return {
            'statusCode': 200,
            'body': json.dumps({"message": "Profile complete"})
        }
    
    except Exception as e:
        print(f"Error checking profile: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({"error": str(e)})
        }
