import json
import boto3

dynamodb = boto3.resource("dynamodb")
TABLE_NAME = "Users"

def lambda_handler(event, context):
    try:
        print("\U0001F50D Received Event:", json.dumps(event, indent=2))

        # CORS Headers
        cors_headers = {
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Methods": "POST, OPTIONS",
            "Access-Control-Allow-Headers": "Content-Type, Authorization",
        }

        # ✅ Handle Preflight (OPTIONS) Request
        if event.get("httpMethod") == "OPTIONS":
            return {
                "statusCode": 200,
                "headers": cors_headers,
                "body": json.dumps({"message": "CORS preflight request success"})
            }

        # ✅ Ensure the request body is correctly formatted
        if "body" not in event or not event["body"]:
            return {
                "statusCode": 400,
                "headers": cors_headers,
                "body": json.dumps({"error": "Missing request body."}),
            }

        # ✅ Parse JSON body safely
        try:
            body = json.loads(event["body"])
        except json.JSONDecodeError:
            return {
                "statusCode": 400,
                "headers": cors_headers,
                "body": json.dumps({"error": "Invalid JSON format in request body."}),
            }

        # ✅ Extract Email field
        email = body.get("Email")
        if not email:
            return {
                "statusCode": 400,
                "headers": cors_headers,
                "body": json.dumps({"error": "Email parameter is required."}),
            }

        # ✅ Check if user exists in DynamoDB
        table = dynamodb.Table(TABLE_NAME)
        response = table.get_item(Key={"Email": email})

        if "Item" in response:
            return {
                "statusCode": 200,
                "headers": cors_headers,
                "body": json.dumps({"message": f"User {email} already exists."}),
            }

        # ✅ Add new user
        new_user = {"Email": email, "Name": "", "About": "", "Phone": "", "linkedin profile": ""}
        table.put_item(Item=new_user)

        return {
            "statusCode": 201,
            "headers": cors_headers,
            "body": json.dumps({"message": "User added successfully", "user": new_user}),
        }

    except Exception as e:
        print("❌ Lambda Error:", str(e))
        return {
            "statusCode": 500,
            "headers": cors_headers,
            "body": json.dumps({"error": f"Internal Server Error: {str(e)}"}),
        }
