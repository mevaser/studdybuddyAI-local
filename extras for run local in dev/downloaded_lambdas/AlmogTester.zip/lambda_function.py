import os
import json
import boto3
import urllib3
import time
from datetime import datetime
from zoneinfo import ZoneInfo 
from boto3.dynamodb.conditions import Key, Attr
import uuid

# Initialize the DynamoDB resources with explicit region
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
USERS_TABLE = 'Users'
STUDENT_SESSION_TABLE = 'StudentSession'

users_table = dynamodb.Table(USERS_TABLE)
student_session_table = dynamodb.Table(STUDENT_SESSION_TABLE)

http = urllib3.PoolManager()

def get_conversation_history(student_email):
    try:
        # Use scan with filter expression since we can't query by StudentEmail directly
        response = student_session_table.scan(
            FilterExpression=Attr('StudentEmail').eq(student_email),
            Limit=10
        )
        
        # Sort items by Timestamp (most recent first)
        items = sorted(
            response.get('Items', []),
            key=lambda x: x.get('Timestamp', ''),
            reverse=True
        )[:10]
        
        # Format the conversation history for GPT
        history = []
        for item in items:
            history.append({
                'role': 'user',
                'content': item['StudentPrompt']
            })
            history.append({
                'role': 'assistant',
                'content': item['AIAnswer']
            })
        
        print(f"Found {len(items)} previous conversations")
        return history
    except Exception as e:
        print(f"Error fetching conversation history: {str(e)}")
        return []

def lambda_handler(event, context):
    try:
        api_key = os.getenv('api_key')
        if not api_key:
            raise ValueError("API key is not set in environment variables.")

        student_email = event.get('email')
        student_question = event.get('question')

        if not student_email or not student_question:
            print("Invalid input: Missing 'email' or 'question'")
            return {
                'statusCode': 400,
                'body': json.dumps("Invalid input. 'email' and 'question' are required.")
            }

        print(f"Attempting to find student with email: {student_email}")
        print(f"Using DynamoDB table: {USERS_TABLE}")
        
        response = users_table.get_item(Key={'Email': student_email})
        print(f"DynamoDB Response: {json.dumps(response, default=str)}")
        
        student_data = response.get('Item')

        if not student_data:
            print(f"No student found with email: {student_email}")
            return {
                'statusCode': 404,
                'body': json.dumps("Student not found.")
            }

        student_bio = student_data.get('About', 'No About available.')
        student_name = student_data.get('Name', 'No name available.')

        # Get conversation history
        print(f"Fetching conversation history for: {student_email}")
        conversation_history = get_conversation_history(student_email)
        
        # Create system message
        system_message = {
            'role': 'system',
            'content': (
                "You are an AI tutor helping students. Use the conversation history to provide more contextual and personalized responses. "
                "Format your responses using Markdown and use the same language as the student's question."
            )
        }

        # Create the current user message
        current_message = {
            'role': 'user',
            'content': f"Student's name: {student_name}\nStudent's bio: {student_bio}\nQuestion: {student_question}"
        }

        # Combine all messages
        messages = [system_message] + conversation_history + [current_message]

        headers = {
            'Authorization': f'Bearer {api_key}',
            'Content-Type': 'application/json'
        }
        
        gpt_payload = {
            'model': 'gpt-3.5-turbo',
            'messages': messages
        }

        url = "https://api.openai.com/v1/chat/completions"
        start_time = time.time()
        response = http.request("POST", url, body=json.dumps(gpt_payload), headers=headers)
        response_latency = int((time.time() - start_time) * 1000)

        if response.status != 200:
            raise ValueError(f"GPT API call failed: {response.data.decode('utf-8')}")

        model_answer = json.loads(response.data.decode('utf-8'))['choices'][0]['message']['content']
        print(f"GPT Answer: {model_answer}")

        # Log interaction details to DynamoDB
        log_item = {
            'LogID': str(uuid.uuid4()),
            'Timestamp': datetime.now(ZoneInfo("Asia/Jerusalem")).isoformat(),
            'StudentName': student_name,
            'StudentEmail': student_email,
            'StudentPrompt': student_question,
            'StudentBio': student_bio,
            'AIAnswer': model_answer,
            'ModelUsed': gpt_payload['model'],
            'ResponseLatency': response_latency
        }
        student_session_table.put_item(Item=log_item)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'answer': model_answer
            })
        }

    except Exception as error:
        print(f"Exception occurred: {str(error)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(error)})
        }
