import boto3
import json

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'Users'

def lambda_handler(event, context):
    print("Received Event: ", json.dumps(event))

    # ✅ Handle CORS preflight
    if event.get("httpMethod") == "OPTIONS":
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({"message": "CORS preflight passed"})
        }

    # Extract email from queryStringParameters
    query_params = event.get('queryStringParameters', {})
    email = query_params.get('Email') if query_params else None

    # Validate the email parameter
    if not email:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({"error": "Email parameter is required."})
        }

    try:
        # Access the DynamoDB table
        table = dynamodb.Table(TABLE_NAME)

        # Fetch the student data
        response = table.get_item(Key={'Email': email})

        if 'Item' in response:
            student = response['Item']
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                    'Content-Type': 'application/json'
                },
                'body': json.dumps(student)
            }
        else:
            return {
                'statusCode': 404,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                    'Content-Type': 'application/json'
                },
                'body': json.dumps({"error": f"Student with email {email} not found."})
            }

    except Exception as e:
        print("Error: ", str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                'Content-Type': 'application/json'
            },
            'body': json.dumps({"error": f"Error retrieving student: {str(e)}"})
        }
