"""Chain that does self ask with search.

Heavily borrowed from https://github.com/ofirpress/self-ask
"""
