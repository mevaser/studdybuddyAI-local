import boto3
import json

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'Users'

def lambda_handler(event, context):
    print("Received Event: ", json.dumps(event))

    try:
        # Access the DynamoDB table
        table = dynamodb.Table(TABLE_NAME)

        # Fetch all students using the scan operation
        response = table.scan()
        students = response.get('Items', [])

        # Return the list of students
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, HEAD, POST',
                'Access-Control-Allow-Headers': 'Content-Type',
            },
            'body': json.dumps(students)
        }

    except Exception as e:
        # Handle unexpected errors
        print("Error: ", str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, HEAD, POST',
                'Access-Control-Allow-Headers': 'Content-Type',
            },
            'body': json.dumps({"error": f"Error retrieving students: {str(e)}"})
        }
