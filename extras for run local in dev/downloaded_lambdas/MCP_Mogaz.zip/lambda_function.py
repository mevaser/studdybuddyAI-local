import os
import json
from openai import OpenAI

# שליפת מפתח מה־environment (לא כתוב ישירות בקוד!)
api_key = os.environ.get("apiKey")
if not api_key:
    raise Exception("No OpenAI API key found in environment variable 'apikey'")

client = OpenAI(api_key=api_key)

# MCP Schema
def create_mcp_request(tool_name, input_data):
    return {
        "tool": tool_name,
        "input": input_data,
        "version": "1.0"
    }

def create_mcp_response(result, success=True):
    return {
        "success": success,
        "output": result
    }

# מחשבון
def calculator_tool(input_data):
    try:
        op = input_data.get("operation")
        num = float(input_data.get("number", 0))
        if op == "sqrt":
            return create_mcp_response(num ** 0.5)
        elif op == "multiply":
            factors = input_data.get("factors", [])
            result = 1
            for f in factors:
                result *= float(f)
            return create_mcp_response(result)
        else:
            return create_mcp_response("Unsupported operation", success=False)
    except Exception as e:
        return create_mcp_response(str(e), success=False)

# תרגום בסיסי
def translator_tool(input_data):
    translations = {
        "24": {"spanish": "veinticuatro", "english": "twenty-four"},
        "25": {"spanish": "veinticinco", "english": "twenty-five"}
    }
    try:
        text = str(input_data.get("text"))
        lang = input_data.get("lang", "spanish")
        return create_mcp_response(translations.get(text, {}).get(lang, "Translation not found"))
    except Exception as e:
        return create_mcp_response(str(e), success=False)

# רשימת כלים
TOOLS = {
    "calculator": calculator_tool,
    "translator": translator_tool
}

def extract_tools_with_gpt(user_prompt):
    system_prompt = (
        "אתה עוזר שמקבל בקשות ממשתמשים ומחליט אילו כלים צריך להפעיל. "
        "החזר רשימה של קריאות MCP בפורמט JSON, למשל: "
        "[{\"tool\": \"calculator\", \"input\": {\"operation\": \"sqrt\", \"number\": 576}}, "
        "{\"tool\": \"translator\", \"input\": {\"text\": \"24\", \"lang\": \"spanish\"}}] "
        "אם הבקשה היא מכפלה כמו 5*4 או 5*5, הפק קריאה כזו: "
        "{\"tool\": \"calculator\", \"input\": {\"operation\": \"multiply\", \"factors\": [5,4]}}"
    )

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
    )

    # נסה לפרסר JSON, עם טיפול בגרשיים בודדים
    try:
        return json.loads(response.choices[0].message.content.replace("'", "\""))
    except Exception as e:
        return [{"tool": "error", "input": {"message": str(e)}}]

def lambda_handler(event, context):
    # צפה ל־event מהסוג: {"prompt": "חשב את השורש של 576 ותרגם לספרדית"}
    user_prompt = event.get("prompt", "")
    if not user_prompt:
        return {"statusCode": 400, "body": json.dumps("Missing 'prompt'")}

    steps = extract_tools_with_gpt(user_prompt)
    results = []

    for step in steps:
        tool = step.get("tool")
        input_data = step.get("input")

        if tool in TOOLS:
            res = TOOLS[tool](input_data)
            results.append({tool: res["output"]})
        else:
            results.append({"error": f"Tool '{tool}' not found"})

    return {
        "statusCode": 200,
        "body": json.dumps(results, ensure_ascii=False)
    }