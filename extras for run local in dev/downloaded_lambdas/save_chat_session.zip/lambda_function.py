import os
import json
import time
import boto3

# Initialize the DynamoDB resource
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')  # Change to your AWS region

# Define the table
SESSIONS_TABLE = "SessionsData"
sessions_table = dynamodb.Table(SESSIONS_TABLE)

def save_chat_session(sender, receiver, message):
    """Saves a chat message to SessionsData table"""
    timestamp = int(time.time())  # UNIX timestamp
    
    sessions_table.put_item(
        Item={
            "Timestamp": timestamp,  # Unique key for ordering
            "Sender": sender,
            "Receiver": receiver,
            "Message": message
        }
    )