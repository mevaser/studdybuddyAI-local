import boto3
import json

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'Users'

def lambda_handler(event, context):
    print("Received Event: ", json.dumps(event))

    body = json.loads(event.get('body', '{}'))
    email = body.get('Email')  # Extract the email from request

    if not email:
        return {
            'statusCode': 400,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            },
            'body': json.dumps({"error": "Email parameter is required."})
        }

    try:
        table = dynamodb.Table(TABLE_NAME)

        # Fetch the existing student record
        response = table.get_item(Key={'Email': email})

        if 'Item' in response:
            student = response['Item']

            # Prevent the user from updating the email
            updated_student = {
                'Email': student['Email'],  # Keep the existing email, prevent user change
                'Name': body.get('Name', student.get('Name', '')),
                'About': body.get('About', student.get('About', '')),
                'Phone': body.get('Phone', student.get('Phone', '')),
                'linkedin profile': body.get('linkedin', student.get('linkedin profile', '')),
            }

            # Update item in DynamoDB
            table.put_item(Item=updated_student)

            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                },
                'body': json.dumps({"message": "Profile updated successfully", "updatedData": updated_student})
            }

        else:
            return {
                'statusCode': 404,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
                },
                'body': json.dumps({"error": f"Student with email {email} not found."})
            }

    except Exception as e:
        print("Error: ", str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, Authorization',
            },
            'body': json.dumps({"error": f"Error updating student: {str(e)}"})
        }
