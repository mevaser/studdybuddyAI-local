import boto3
import json
from boto3.dynamodb.conditions import Attr
from collections import Counter
from datetime import datetime
from collections import defaultdict

# Initialize DynamoDB connection
dynamodb = boto3.resource("dynamodb")
table = dynamodb.Table("StudentSession")

# Keyword mapping for Networking topics
networking_topic_mappings = {
    "Introduction to Networking": ["introduction", "networking basics", "overview"],
    "LAN vs. WAN": ["lan", "wan", "local area network", "wide area network"],
    "Reference Models & Layered Architecture": ["reference model", "layered architecture", "network edge", "network core", "circuit switching", "packet switching"],
    "Application Layer & Protocols": ["application layer", "http", "https", "dns", "ftp", "smtp", "pop", "imap", "email", "web-mail", "cookies"],
    "Transport Layer & Protocols": ["transport layer", "tcp", "udp", "tcp/ip", "connectionless", "connection-oriented", "reliable communication", "unreliable communication"],
    "Network Layer": ["network layer", "ip", "dhcp", "subnet", "ipv6", "ip datagram"],
    "Routing & ICMP": ["icmp", "rip", "router", "routing", "intra-as", "security issues"],
    "Data Link Layer": ["data link layer", "llc", "mac", "error detection", "error correction", "lan technologies", "arp", "ethernet", "token ring", "ppp"],
    "Physical Layer": ["physical layer", "transmission media", "wireless", "narrowband", "broadband", "telephone system", "radio", "satellites", "isdn", "dsl"],
    "Encryption & Secure Communication": ["encryption", "secure email", "ipsec"],
    "Error Detection & Correction": ["parity bit", "hamming code"]
}

# Keyword mapping for C# topics
csharp_topic_mappings = {
    "Transition from C to C#": ["transition to c#", "c to c#"],
    "OOP Basics and Accessing Objects": ["object oriented", "oop", "classes", "methods", "accessing objects", "c# basics", "c# syntax"],
    "Encapsulation and Object Arrays": ["encapsulation", "access modifiers", "private", "public", "this keyword", "destructor", "array of objects"],
    "Static Members, Constants, ENUM, ArrayList": ["static variable", "static method", "constants", "enum", "arraylist", "static class"],
    "Basic GUI and Event Driven Programming": ["gui basics", "windows forms", "controls", "event driven programming", "messagebox", "forms"],
    "Advanced GUI and Object Interaction": ["advanced gui", "checkbox", "listbox", "combobox", "picturebox", "gui interaction", "date time picker"],
    "Inheritance and Method Overriding": ["inheritance", "base class", "derived class", "constructor", "method overriding"],
    "Exception Handling and Try-Catch-Finally": ["exceptions", "exception handling", "try catch", "finally", "throw", "uncaught exceptions", "custom exceptions"],
    "Polymorphism, Abstract Classes and Interfaces": ["polymorphism", "virtual method", "override", "abstract class", "interface", "as keyword", "is keyword"],
    "Operator Overloading and Collections": ["operator overloading", "collections", "stack", "list", "dictionary", "arraylist", "queue"],
    "File Handling and Directories": ["file handling", "directories", "folders", "files", "data storage"],
    "Multiple Windows and String Manipulation": ["multiple windows", "string manipulation", "string operations", "string methods"]
}

def lambda_handler(event, context):
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS, GET",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Max-Age": "86400"
    }

    if event.get("httpMethod") == "OPTIONS":
        return {"statusCode": 200, "headers": headers, "body": ""}

    try:
        # Support both direct event (from Lambda test) and API Gateway (via HTTP POST)
        body = event.get("body")
        if isinstance(body, str):
            body = json.loads(body)
        elif body is None:
            body = event  # Use the full event directly if no "body" key exists
    except (json.JSONDecodeError, TypeError):
        return {"statusCode": 400, "headers": headers, "body": json.dumps({"error": "Invalid or missing JSON body"})}

    start_date = body.get("startDate")
    end_date = body.get("endDate")
    include_top5 = str(body.get("includeTop5", "false")).lower() == "true"
    include_inactive = str(body.get("includeInactive", "false")).lower() == "true"
    include_recommendations = str(body.get("includeRecommendations", "false")).lower() == "true"

    if not start_date or not end_date:
        return {"statusCode": 400, "headers": headers, "body": json.dumps({"error": "Missing startDate or endDate"})}

    # Scan all items, then filter by ISO timestamp range manually
    try:
        response = table.scan()
        all_items = response.get("Items", [])

        start_dt = datetime.fromisoformat(start_date)
        end_dt = datetime.fromisoformat(end_date)

        items = []
        for item in all_items:
            ts = item.get("Timestamp")
            if ts:
                try:
                    ts_dt = datetime.fromisoformat(ts.split("+")[0])
                    if start_dt <= ts_dt <= end_dt:
                        items.append(item)
                except ValueError:
                    continue

        
    except Exception as e:
        return {"statusCode": 500, "headers": headers, "body": json.dumps({"error": f"DynamoDB error: {str(e)}"})}

    # Prepare data containers
    result = {"range": {"start": start_date, "end": end_date}}
    email_counts = {}
    networking_counts = {topic: 0 for topic in networking_topic_mappings}
    csharp_counts = {topic: 0 for topic in csharp_topic_mappings}
    topic_subtopic_counts = {}
    prompt_counter = Counter()

    for item in items:
        email = item.get("StudentEmail")
        subtopic = item.get("subtopic", "Unknown")
        topic = item.get("topic", "Unknown")
        prompt = item.get("StudentPrompt", "").strip()

        if email:
            email_counts[email] = email_counts.get(email, 0) + 1

        subtopic_text = subtopic.lower()
        topic_text = topic.lower()

        if "network" in topic_text or "communication" in topic_text:
            for t, keywords in networking_topic_mappings.items():
                if any(k in subtopic_text for k in keywords):
                    networking_counts[t] += 1
                    break

        if topic_text == "programming" and "c#" in subtopic_text:
            for t, keywords in csharp_topic_mappings.items():
                if any(k in subtopic_text for k in keywords):
                    csharp_counts[t] += 1
                    break

        topic_subtopic_counts.setdefault(topic, {}).setdefault(subtopic, 0)
        topic_subtopic_counts[topic][subtopic] += 1

        if prompt:
            prompt_counter[prompt] += 1

        # Unified: Group by date AND by student+date
        questions_by_date = defaultdict(int)
        questions_per_student_per_day = defaultdict(lambda: defaultdict(int))

        for item in items:
            ts = item.get("Timestamp")
            email = item.get("StudentEmail")

            if ts:
                try:
                    date_only = ts.split("T")[0]  # Format: YYYY-MM-DD
                    questions_by_date[date_only] += 1

                    if email:
                        questions_per_student_per_day[email][date_only] += 1
                except Exception:
                    continue

        # Format: total per date
        result["questionsOverTime"] = [
            {"date": date, "count": questions_by_date[date]}
            for date in sorted(questions_by_date)
        ]

        # Format: per student
        result["questionsOverTimeByStudent"] = {
            email: [{"date": date, "count": count} for date, count in sorted(counts.items())]
            for email, counts in questions_per_student_per_day.items()
        }


    # Summary info
    result["summary"] = {
        "totalQuestions": len(items),
        "totalStudents": len(email_counts),
        "averageQuestionsPerStudent": round(len(items) / max(1, len(email_counts)), 2)
    }

    # Top topics per course
    result["topTopicsPerCourse"] = {
        "Networking": sorted(networking_counts.items(), key=lambda x: x[1], reverse=True)[:3],
        "C#": sorted(csharp_counts.items(), key=lambda x: x[1], reverse=True)[:3]
    }

    # Most frequent questions
    result["frequentQuestions"] = [
        {"question": q, "count": c} for q, c in prompt_counter.items() if c > 2
    ]

    # Top 5 students by activity
    if include_top5:
        top5 = sorted(email_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        email_to_name = {
            item.get("StudentEmail"): item.get("StudentName") or item.get("StudentEmail", "").split("@")[0]
            for item in items if item.get("StudentEmail")
        }
        result["top5"] = [
            {"name": email_to_name.get(email, email.split("@")[0]), "count": count}
            for email, count in top5
        ]

    # Inactive users (less than 5 questions)
    if include_inactive:
        email_to_name = {
            item.get("StudentEmail"): item.get("StudentName") or item.get("StudentEmail", "").split("@")[0]
            for item in items if item.get("StudentEmail")
        }
        result["inactiveUsers"] = [
            {"name": email_to_name.get(email, email.split("@")[0]), "count": count}
            for email, count in email_counts.items() if count < 5
        ]

    # Recommendations for lecturer
    if include_recommendations:
        max_net_topic = max(networking_counts, key=networking_counts.get, default=None)
        max_net_count = networking_counts.get(max_net_topic, 0) if max_net_topic else 0
        max_cs_topic = max(csharp_counts, key=csharp_counts.get, default=None)
        max_cs_count = csharp_counts.get(max_cs_topic, 0) if max_cs_topic else 0

        rec = "Based on the question analysis:\n"
        if max_net_count > 0:
            rec += f"It is recommended to review and emphasize the topic: {max_net_topic} ({max_net_count} questions)\n"
        if max_cs_count > 0:
            rec += f"It is recommended to review and emphasize the topic: {max_cs_topic} ({max_cs_count} questions)\n"
        if max_net_count == 0 and max_cs_count == 0:
            rec += "No significant difficulties were identified based on student questions.\n"

        result["recommendations"] = rec

    # Subtopic breakdown by topic
    result["topicSubtopicBreakdown"] = topic_subtopic_counts

    return {
        "statusCode": 200,
        "headers": headers,
        "body": json.dumps(result, ensure_ascii=False)
    }
