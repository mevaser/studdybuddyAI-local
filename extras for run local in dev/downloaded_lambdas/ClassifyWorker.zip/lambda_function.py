import boto3
import json
import os

CLASSIFIER_FUNCTION_NAME = os.getenv("CLASSIFIER_FUNCTION_NAME", "classify_topic")
DYNAMODB_TABLE_NAME = "StudentSession"

lambda_client = boto3.client('lambda')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
log_table = dynamodb.Table(DYNAMODB_TABLE_NAME)

def lambda_handler(event, context):
    success = 0
    failed = 0
    missing = 0

    for record in event.get("Records", []):
        print("📥 Got record:", record)
        print("📦 Raw body:", record.get("body"))

        try:
            message = json.loads(record["body"])
            print("🧾 Parsed message:", message)
            log_id = message.get("log_id")
            prompt = message.get("question", "")
            answer = message.get("answer", "")

            if not log_id or not prompt or not answer:
                print(f"⚠️ Missing fields in record: {message}")
                missing += 1
                continue

            # 🔁 Step 1: Invoke Gemini classifier
            payload = {
                "StudentPrompt": prompt,
                "AIAnswer": answer
            }

            response = lambda_client.invoke(
                FunctionName=CLASSIFIER_FUNCTION_NAME,
                InvocationType="RequestResponse",
                Payload=json.dumps(payload)
            )

            print("📨 Raw invoke response:", response)

            try:
                raw_body = response["Payload"].read().decode("utf-8")
                print("📤 Payload body string:", raw_body)
                body = json.loads(raw_body)
            except Exception as parse_err:
                print(f"❌ Failed to parse response body: {parse_err}")
                body = {}

            topic = body.get("topic", "Unclassified")
            subtopic = body.get("subtopic", "Unclassified")

            # 💾 Step 2: Update DynamoDB
            log_table.update_item(
                Key={'LogID': log_id},
                UpdateExpression="SET topic = :t, subtopic = :s",
                ExpressionAttributeValues={
                    ':t': topic,
                    ':s': subtopic
                }
            )

            print(f"✅ Updated LogID {log_id}: {topic} / {subtopic}")
            success += 1

        except Exception as e:
            print(f"❌ Exception in record: {str(e)}")
            failed += 1

    return {
        "statusCode": 200,
        "body": json.dumps({
            "success": success,
            "failed": failed,
            "missing": missing
        })
    }
