import boto3
import os
import json
import re
from opensearchpy import OpenSearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth

# === ENV VARS (set in Lambda configuration) ===
CONFIG_TABLE = os.getenv("CONFIG_TABLE", "StudyBuddyCourseConfig")
REGION = os.getenv("AWS_REGION", "us-east-1")
OS_ENDPOINT = os.getenv("OS_ENDPOINT")  # without https://
OS_INDEX = None  # loaded dynamically per course

# === Setup AWS clients ===
dynamodb = boto3.client("dynamodb")
credentials = boto3.Session().get_credentials().get_frozen_credentials()
awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, REGION, 'es', session_token=credentials.token)
os_client = OpenSearch(
    hosts=[{'host': OS_ENDPOINT, 'port': 443}],
    http_auth=awsauth,
    use_ssl=True,
    verify_certs=True,
    connection_class=RequestsHttpConnection
)

# === Helper: detect language ===
def detect_lang(text):
    return "he" if re.search(r"[א-ת]", text) else "en"

# === Helper: get course config ===
def get_course_config(course_id):
    res = dynamodb.get_item(
        TableName=CONFIG_TABLE,
        Key={"courseId": {"S": course_id}}
    )
    if "Item" not in res:
        raise Exception(f"Course ID '{course_id}' not found in DynamoDB.")
    item = res["Item"]
    return {k: list(v.values())[0] for k, v in item.items()}

# === Entry point ===
def lambda_handler(event, context):
    try:
        params = event.get("queryStringParameters", {})
        question = params.get("q")
        course_id = params.get("course")

        if not question or not course_id:
            return {"statusCode": 400, "body": "Missing query or courseId"}

        lang = detect_lang(question)
        cfg = get_course_config(course_id)
        index_name = cfg.get("indexName")
        if not index_name:
            raise Exception("Missing indexName in config")

        # === Use Titan Embed (optional, use dummy vector for now) ===
        vector = embed_question_with_dummy(question)

        # === Query OpenSearch ===
        response = os_client.search(
            index=index_name,
            body={
                "size": 4,
                "query": {
                    "knn": {
                        "vector": {
                            "vector": vector,
                            "k": 4
                        }
                    }
                }
            }
        )

        hits = response["hits"]["hits"]
        results = [hit["_source"] for hit in hits]
        context_text = "\n\n".join([r["text"] for r in results])

        return {
            "statusCode": 200,
            "body": json.dumps({
                "course": course_id,
                "lang": lang,
                "context": context_text,
                "sources": results
            }),
            "headers": { "Content-Type": "application/json" }
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)}),
            "headers": { "Content-Type": "application/json" }
        }

# === TEMP: Dummy vector (simulate embedding) ===
def embed_question_with_dummy(text):
    import hashlib
    h = hashlib.md5(text.encode()).hexdigest()
    return [float(int(h[i:i+2], 16)) / 255 for i in range(0, 32, 2)] + [0.0] * (1536 - 16)
